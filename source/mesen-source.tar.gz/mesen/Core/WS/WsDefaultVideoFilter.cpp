#include "pch.h"
#include "WS/WsDefaultVideoFilter.h"
#include "WS/WsConsole.h"
#include "Shared/EmuSettings.h"
#include "Shared/Emulator.h"
#include "Shared/ColorUtilities.h"

WsDefaultVideoFilter::WsDefaultVideoFilter(Emulator* emu, WsConsole* console, bool applyNtscFilter) : BaseVideoFilter(emu), _ntscFilter(emu)
{
	_emu = emu;
	_console = console;
	_applyNtscFilter = applyNtscFilter;
	InitLookupTable();
}

void WsDefaultVideoFilter::InitLookupTable()
{
	VideoConfig config = _emu->GetSettings()->GetVideoConfig();

	InitConversionMatrix(config.Hue, config.Saturation);

	for(int rgb444 = 0; rgb444 < 0x1000; rgb444++) {
		uint8_t r = (rgb444 >> 8) & 0xF;
		uint8_t g = (rgb444 >> 4) & 0xF;
		uint8_t b = rgb444 & 0xF;

		if(_adjustColors) {
			if(!_console->IsColorModel()) {
				//Same formula as what asie recently implemented for ares
				auto applyGamma = [](uint32_t color, uint32_t min, uint32_t max) {
					return min + (uint32_t)(pow(color / 15.0, 1 / 2.2) * (max - min));
				};

				r = applyGamma(r, 0x2B, 0xE0);
				g = applyGamma(g, 0x2B, 0xDB);
				b = applyGamma(b, 0x26, 0xCD);
			} else {
				uint8_t r2 = r * 13 + g * 2 + b;
				uint8_t g2 = g * 12 + b * 4;
				uint8_t b2 = r * 3 + g * 2 + b * 11;
				r = r2;
				g = g2;
				b = b2;
			}
		} else {
			r = ColorUtilities::Convert4BitTo8Bit(r);
			g = ColorUtilities::Convert4BitTo8Bit(g);
			b = ColorUtilities::Convert4BitTo8Bit(b);
		}

		if(config.Hue != 0 || config.Saturation != 0 || config.Brightness != 0 || config.Contrast != 0) {
			ApplyColorOptions(r, g, b, config.Brightness, config.Contrast);
			_calculatedPalette[rgb444] = 0xFF000000 | (r << 16) | (g << 8) | b;
		} else {
			_calculatedPalette[rgb444] = 0xFF000000 | (r << 16) | (g << 8) | b;
		}
	}

	_videoConfig = config;
}

FrameInfo WsDefaultVideoFilter::GetFrameInfo()
{
	if(_applyNtscFilter) {
		FrameInfo frameInfo;
		frameInfo.Width = SNES_NTSC_OUT_WIDTH(_baseFrameInfo.Width);
		frameInfo.Height = _baseFrameInfo.Height;
		return frameInfo;
	}
	return BaseVideoFilter::GetFrameInfo();
}

void WsDefaultVideoFilter::OnBeforeApplyFilter()
{
	VideoConfig config = _emu->GetSettings()->GetVideoConfig();
	WsConfig wsConfig = _emu->GetSettings()->GetWsConfig();

	bool adjustColors = wsConfig.LcdAdjustColors;
	if(_videoConfig.Hue != config.Hue || _videoConfig.Saturation != config.Saturation || _videoConfig.Contrast != config.Contrast || _videoConfig.Brightness != config.Brightness || _adjustColors != adjustColors) {
		_adjustColors = adjustColors;
		InitLookupTable();
	}
	_blendFilter.SetEnabled(wsConfig.BlendFrames);
	_videoConfig = config;
}

void WsDefaultVideoFilter::ApplyFilter(uint16_t* ppuOutputBuffer)
{
	uint32_t* out = GetOutputBuffer();
	FrameInfo size = _baseFrameInfo;

	for(uint32_t i = 0, len = size.Height * size.Width; i < len; i++) {
		out[i] = _calculatedPalette[ppuOutputBuffer[i]];
	}

	if(_applyNtscFilter) {
		_ntscFilter.ApplyFilter(out, size.Width, size.Height, IsOddFrame());
	}
}
